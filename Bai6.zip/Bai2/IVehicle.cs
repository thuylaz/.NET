﻿namespace BaiTap
{
    internal interface IVehicle
    {
        void Input();
        void Output();
    }
}
